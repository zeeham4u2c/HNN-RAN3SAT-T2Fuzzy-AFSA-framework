from __future__ import annotations
import argparse
import json
from pathlib import Path
import pandas as pd
from hnn_ran3sat_t2fuzzy_afsa.experiment import run_experiment

def main():
    parser = argparse.ArgumentParser(description="Run independent seeded experiments (default seeds 1--30).")
    parser.add_argument("--csv", required=True)
    parser.add_argument("--target", required=True)
    parser.add_argument("--output", default="results/30_seed_runs")
    parser.add_argument("--start-seed", type=int, default=1)
    parser.add_argument("--count", type=int, default=30)
    parser.add_argument("--afsa-iterations", type=int, default=500)
    parser.add_argument("--population-size", type=int, default=50)
    args = parser.parse_args()

    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    rows = []
    for seed in range(args.start_seed, args.start_seed + args.count):
        metrics = run_experiment(
            args.csv, args.target, out / f"seed_{seed:02d}",
            seed=seed, afsa_iterations=args.afsa_iterations,
            population_size=args.population_size)
        rows.append(metrics)
        print(f"seed={seed}: accuracy={metrics['accuracy']:.4f}, F1={metrics['f1']:.4f}")
    pd.DataFrame(rows).to_csv(out / "summary_30_runs.csv", index=False)
    (out / "summary_statistics.json").write_text(
        json.dumps(pd.DataFrame(rows).select_dtypes("number").agg(["mean", "std"]).to_dict(),
                   indent=2), encoding="utf-8")

if __name__ == "__main__":
    main()
