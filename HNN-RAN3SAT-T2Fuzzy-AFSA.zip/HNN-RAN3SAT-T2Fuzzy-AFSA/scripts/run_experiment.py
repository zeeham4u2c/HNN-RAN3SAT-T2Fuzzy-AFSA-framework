from hnn_ran3sat_t2fuzzy_afsa.experiment import main

if __name__ == "__main__":
    main()
