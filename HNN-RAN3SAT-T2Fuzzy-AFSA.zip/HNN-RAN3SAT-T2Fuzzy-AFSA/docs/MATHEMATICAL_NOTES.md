# Mathematical and implementation notes

## Interval Type-2 Gaussian membership

For feature value `x`, center `c`, and positive spread `sigma`:

\[
\mu(x;c,\sigma)=\exp[-\tfrac12((x-c)/\sigma)^2].
\]

The upper and lower membership grades use `sigma_upper > sigma_lower`, yielding
`0 <= lower <= upper <= 1`. The implementation exposes both values and a
convex blend for ranking class prototypes. This blend is a practical classifier
score; it is not asserted to be a full Karnik--Mendel type-reduction procedure.

## Clause penalty and bipolar encoding

A Boolean variable is represented by `s in {-1,+1}`. A positive literal has
value `s`; a negative literal has value `-s`. For a clause with literals
`l_1,...,l_q`, the penalty is

\[
P_C(s)=\lambda_C\prod_{j=1}^{q}(1-l_j(s))/2.
\]

This penalty is zero exactly when at least one literal is true. It is nonzero
only when all literals are false. For `q <= 3`, expansion has degree at most 3.

## HNN update

The implementation uses an explicit energy evaluator and tries flipping one
bipolar neuron at a time. A flip is accepted only if it strictly decreases
energy (ties preserve the current state). Since the state space is finite and
accepted flips strictly decrease energy, the procedure terminates. This
argument establishes a coordinate-wise local minimum, not a global minimum.

## AFSA

AFSA maximizes a user-supplied objective over bounded real vectors. The
preying, swarming, following, and random movement operators are implemented
with explicit bounds and seeded random number generation. In the example
classifier, AFSA searches two positive spread multipliers. It does not tune the
full manuscript vector of centers, upper/lower spreads, and all rule weights.
