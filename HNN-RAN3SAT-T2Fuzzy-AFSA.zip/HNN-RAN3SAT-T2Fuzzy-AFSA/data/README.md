# Data directory

Place locally obtained, legally usable datasets here. Raw datasets are excluded from version control by `.gitignore`.

Prepare a CSV containing numeric predictors and one binary target column. Keep a separate record of:
- original source URL and download date;
- exact target mapping;
- excluded columns and missing-value handling;
- selected feature names and order;
- train/validation/test indices;
- random seed.

Do not commit credentials or identifiable customer/borrower information.
