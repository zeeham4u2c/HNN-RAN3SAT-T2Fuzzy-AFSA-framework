import numpy as np
from hnn_ran3sat_t2fuzzy_afsa.sat import Clause, clause_penalty, formula_satisfied, encode_and_tseitin

def test_clause_penalty_zero_when_satisfied():
    clause = Clause(((0, True), (1, False), (2, True)), 2.0)
    assert clause_penalty(np.array([1, 1, -1]), clause) == 0.0
    assert clause_penalty(np.array([-1, 1, -1]), clause) == 2.0

def test_tseitin_and_chain_has_bounded_clause_width():
    clauses = encode_and_tseitin([1, 2, 3, 4], 5)
    assert all(1 <= len(c) <= 3 for c in clauses)
