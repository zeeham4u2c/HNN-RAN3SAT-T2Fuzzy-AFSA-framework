import numpy as np
from hnn_ran3sat_t2fuzzy_afsa.fuzzy import interval_type2_gaussian

def test_it2_memberships_are_ordered():
    x = np.linspace(-3, 3, 20)
    lo, hi = interval_type2_gaussian(x, 0.0, 0.6, 1.2)
    assert np.all(lo >= 0)
    assert np.all(hi <= 1)
    assert np.all(lo <= hi + 1e-12)
