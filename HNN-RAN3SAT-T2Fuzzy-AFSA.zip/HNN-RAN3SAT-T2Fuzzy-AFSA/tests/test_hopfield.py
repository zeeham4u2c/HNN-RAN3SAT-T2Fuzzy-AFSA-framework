import numpy as np
from hnn_ran3sat_t2fuzzy_afsa.hopfield import BipolarHopfield
from hnn_ran3sat_t2fuzzy_afsa.sat import Clause

def test_hopfield_energy_nonincreasing():
    clauses = [Clause(((0, True), (1, True)), 2.0),
               Clause(((0, False), (1, False)), 2.0)]
    net = BipolarHopfield(2, clauses=clauses, biases=np.array([0.2, 0.8]), seed=4)
    result = net.run(np.array([-1, -1]))
    assert np.all(np.diff(result["energy_history"]) <= 1e-12)
    assert np.sum(result["state"] == 1) == 1
