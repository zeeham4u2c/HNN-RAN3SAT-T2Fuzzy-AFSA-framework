# HNN-RAN3SAT-T2Fuzzy-AFSA

Research-code starter implementation for the manuscript:

**Interval Type-2 Fuzzy Random 3-SAT Representation in Third-Order Hopfield Networks with AFSA Optimization for Uncertainty-Aware Classification in Digital Finance**

This repository contains an executable, documented **prototype implementation** of the computational components described in the manuscript. It is designed to make the workflow inspectable and extensible. It does **not** claim to reproduce the manuscript's reported 93.82% pooled accuracy, AUC values, runtime, or other reported results. Those values require the original feature-selection indices, exact train/validation/test partitions, raw prediction files, complete network indexing, and confirmed output-decoding protocol, none of which are fully specified in the manuscript text supplied.

## Components

- `src/hnn_ran3sat_t2fuzzy_afsa/preprocessing.py`: leakage-aware numeric preprocessing and train-only SMOTE (optional).
- `fuzzy.py`: interval Type-2 Gaussian membership functions.
- `sat.py`: Boolean clauses, random 3-SAT generation, and Tseitin AND-chain encoding utilities.
- `hopfield.py`: bipolar asynchronous Hopfield refinement using an explicit polynomial clause-penalty energy.
- `afsa.py`: bounded Artificial Fish Swarm Algorithm (preying, swarming, following, random movement).
- `classifier.py`: binary classification prototype combining IT2 class-membership scores, one-hot output constraints, and HNN state refinement.
- `experiment.py`: CSV-based training/evaluation entry point.
- `metrics.py`: classification metrics and ROC data generation.
- `config/default.yaml`: transparent default settings.
- `tests/`: unit tests for core mathematical operations.

## Important methodological qualifications

1. The manuscript describes binary benchmark labels but also mentions three output states (`-1`, `0`, `+1`). This implementation uses **binary output only** (`0` and `1`) so that standard binary metrics are well-defined. Abstention is not silently introduced.
2. The manuscript gives both 500 AFSA iterations and 300 generations in different places. The configuration below uses 500 as the default because that is the value in the AFSA parameter table; change it only after deciding which protocol the paper will report.
3. The code uses the explicit nonnegative clause penalty
   \[
   P_C(s)=\lambda_C\prod_{l\in C}\frac{1-l(s)}{2},
   \]
   so a clause contributes zero when satisfied and a positive penalty when all its literals are false. This is the safe implementation of the general clause penalty in the manuscript.
4. A local HNN minimum is not guaranteed to satisfy every clause or be the global minimum. The HNN code reports its terminal energy and whether the encoded clauses are satisfied.
5. The fuzzy classifier is an executable reference design based on class-conditional Gaussian interval memberships. It is not a reconstruction of the manuscript's unspecified full neuron map (`N=65M+15`) or all seven energy subcomponents. The exact original model requires the complete rule-to-neuron and clause-generation specification.
6. The random 3-SAT utilities are representation/validation tools. They are not a complete SAT solver and do not establish equivalence between continuous IT2 inference and the Boolean surrogate.

## Installation

Python 3.9+ is recommended.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
pip install -e .
```

## Run tests

```bash
pytest -q
```

## Run a CSV experiment

Your CSV must contain a binary target column and numeric predictor columns. Do not upload private financial/customer data to GitHub.

```bash
python -m hnn_ran3sat_t2fuzzy_afsa.experiment \
  --csv data/your_dataset.csv \
  --target Class \
  --output results/experiment
```

For Windows PowerShell, the command can be entered on one line:

```powershell
python -m hnn_ran3sat_t2fuzzy_afsa.experiment --csv data/your_dataset.csv --target Class --output results/experiment
```

The program creates `metrics.json`, `predictions.csv`, and `roc_curve.csv`. It uses a stratified train/test split. The AFSA objective uses a validation split drawn only from the training partition; the test partition is held back until final evaluation.

## Dataset notes

The manuscript names the following benchmark sources:

- Credit-card fraud: Kaggle `mlg-ulb/creditcardfraud`.
- LendingClub / peer-to-peer lending: Kaggle `wordsforthewise/lending-club`.
- Elliptic cryptocurrency transaction data: Kaggle `ellipticco/elliptic-data-set`.

Download data from the official dataset pages under their terms. The repository intentionally does not contain datasets, credentials, or personal financial records. Dataset schemas and target columns differ; prepare a clean CSV with numeric features and a binary target before running the common experiment script.

## Reproducibility

- Random seeds are passed explicitly to NumPy and scikit-learn.
- Default experiment seed: `1`.
- A 30-seed driver is provided: `python scripts/run_30_seeds.py --csv data/your_dataset.csv --target Class --output results/30_seed_runs`. It runs seeds 1--30 by default and saves each run separately plus a summary CSV. Use the same fixed data protocol for all seeds and report the generated run-level results, not values copied from the manuscript.
- Save the actual split indices, selected feature names, environment versions, and run-level predictions before making numerical claims.
- Never copy the manuscript's reported result values into result files. Result files must be generated by executing the code on the actual datasets.

## Manuscript items that must be settled before claiming exact reproduction

- Resolve AFSA count (300 vs 500).
- Define whether the neutral output is an abstention state or remove it from binary experiments.
- Regenerate ROC curves and AUC from the same held-out prediction scores.
- Supply all 30 run-level observations if reporting 30 runs.
- Specify exact selected features, data splits, and preprocessing fit/apply order.
- Audit every Tseitin equivalence and the symmetry of the full third-order tensor used by the intended model.

## Repository layout

```text
HNN-RAN3SAT-T2Fuzzy-AFSA/
├── README.md
├── pyproject.toml
├── requirements.txt
├── .gitignore
├── config/default.yaml
├── data/README.md
├── docs/MATHEMATICAL_NOTES.md
├── results/.gitkeep
├── scripts/run_experiment.py
├── src/hnn_ran3sat_t2fuzzy_afsa/
│   ├── __init__.py
│   ├── afsa.py
│   ├── classifier.py
│   ├── experiment.py
│   ├── fuzzy.py
│   ├── hopfield.py
│   ├── metrics.py
│   ├── preprocessing.py
│   └── sat.py
└── tests/
    ├── test_fuzzy.py
    ├── test_hopfield.py
    └── test_sat.py
```

## Citation

If you use or adapt this software, cite the associated manuscript and provide the repository version/commit hash used for the experiment. Add a formal software citation/DOI after creating a tagged release and, if desired, archiving it with Zenodo.
