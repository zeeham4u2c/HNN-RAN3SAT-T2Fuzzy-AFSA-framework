from __future__ import annotations
import numpy as np

def gaussian_membership(x, center, sigma):
    """Gaussian membership grades; sigma must be strictly positive."""
    x = np.asarray(x, dtype=float)
    sigma = np.asarray(sigma, dtype=float)
    if np.any(sigma <= 0):
        raise ValueError("All Gaussian standard deviations must be positive.")
    return np.exp(-0.5 * ((x - center) / sigma) ** 2)

def interval_type2_gaussian(x, center, sigma_lower, sigma_upper):
    """Return (lower, upper) IT2 grades with sigma_upper > sigma_lower > 0."""
    if np.any(np.asarray(sigma_lower) <= 0) or np.any(np.asarray(sigma_upper) <= np.asarray(sigma_lower)):
        raise ValueError("Require sigma_upper > sigma_lower > 0.")
    lower = gaussian_membership(x, center, sigma_lower)
    upper = gaussian_membership(x, center, sigma_upper)
    # Numerical protection and explicit FOU ordering.
    lower = np.minimum(lower, upper)
    return lower, upper

def interval_score(lower, upper, upper_weight=0.5):
    """Convex score between lower and upper grades (not KM type-reduction)."""
    if not 0.0 <= upper_weight <= 1.0:
        raise ValueError("upper_weight must lie in [0, 1].")
    return (1.0 - upper_weight) * np.asarray(lower) + upper_weight * np.asarray(upper)
