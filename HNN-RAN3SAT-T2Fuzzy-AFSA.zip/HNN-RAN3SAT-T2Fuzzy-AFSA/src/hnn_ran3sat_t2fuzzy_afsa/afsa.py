from __future__ import annotations
import numpy as np

class ArtificialFishSwarm:
    """Bounded AFSA maximizer with preying, swarming, following and random moves."""
    def __init__(self, bounds, population_size=50, max_iterations=500,
                 visual=1.0, step=0.1, crowding_factor=0.618,
                 try_number=5, visual_decay=0.7, step_decay=0.7,
                 elite_count=2, seed=1, tolerance=1e-6):
        self.bounds = np.asarray(bounds, dtype=float)
        if self.bounds.ndim != 2 or self.bounds.shape[1] != 2 or np.any(self.bounds[:, 0] >= self.bounds[:, 1]):
            raise ValueError("bounds must be a (dimension, 2) array with lower < upper.")
        self.population_size = int(population_size)
        self.max_iterations = int(max_iterations)
        self.visual0, self.step0 = float(visual), float(step)
        self.crowding0 = float(crowding_factor)
        self.try_number = int(try_number)
        self.visual_decay, self.step_decay = float(visual_decay), float(step_decay)
        self.elite_count = max(1, min(int(elite_count), self.population_size))
        self.rng = np.random.default_rng(seed)
        self.tolerance = float(tolerance)

    def optimize(self, objective):
        lo, hi = self.bounds[:, 0], self.bounds[:, 1]
        dim = len(lo)
        pop = self.rng.uniform(lo, hi, size=(self.population_size, dim))
        scores = np.asarray([objective(x) for x in pop], dtype=float)
        best_idx = int(np.argmax(scores))
        best_x, best_score = pop[best_idx].copy(), float(scores[best_idx])
        trace = [best_score]
        for t in range(self.max_iterations):
            frac = t / max(1, self.max_iterations)
            visual = self.visual0 * (1-frac) ** self.visual_decay
            step = self.step0 * (1-frac) ** self.step_decay
            crowding = self.crowding0 * (1+frac)
            new_pop = pop.copy()
            for i, x in enumerate(pop):
                distances = np.linalg.norm(pop - x, axis=1)
                neighbors = np.where((distances > 0) & (distances <= visual))[0]
                candidate = None
                if len(neighbors):
                    local = neighbors[np.argmax(scores[neighbors])]
                    center = pop[neighbors].mean(axis=0)
                    if scores[local] > scores[i] and scores[local] / max(1, len(neighbors)) > crowding * scores[i]:
                        candidate = x + step * (pop[local] - x) / (np.linalg.norm(pop[local]-x)+1e-12)
                    elif scores[neighbors].mean() / max(1, len(neighbors)) > crowding * scores[i]:
                        candidate = x + step * (center - x) / (np.linalg.norm(center-x)+1e-12)
                if candidate is None:
                    for _ in range(self.try_number):
                        probe = np.clip(x + visual * self.rng.uniform(-1, 1, dim), lo, hi)
                        if objective(probe) > scores[i]:
                            candidate = x + step * (probe-x) / (np.linalg.norm(probe-x)+1e-12)
                            break
                if candidate is None:
                    candidate = x + visual * self.rng.uniform(-1, 1, dim)
                new_pop[i] = np.clip(candidate, lo, hi)
            new_scores = np.asarray([objective(x) for x in new_pop], dtype=float)
            # Elitism: retain the best members from the previous population.
            elite_ids = np.argsort(scores)[-self.elite_count:]
            worst_ids = np.argsort(new_scores)[:self.elite_count]
            new_pop[worst_ids] = pop[elite_ids]
            new_scores[worst_ids] = scores[elite_ids]
            pop, scores = new_pop, new_scores
            idx = int(np.argmax(scores))
            if scores[idx] > best_score + self.tolerance:
                best_x, best_score = pop[idx].copy(), float(scores[idx])
            trace.append(best_score)
        return {"x": best_x, "score": best_score, "trace": np.asarray(trace)}
