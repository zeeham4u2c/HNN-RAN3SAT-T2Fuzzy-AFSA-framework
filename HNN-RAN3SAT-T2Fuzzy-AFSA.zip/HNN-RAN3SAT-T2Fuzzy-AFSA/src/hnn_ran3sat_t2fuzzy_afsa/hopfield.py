from __future__ import annotations
import numpy as np
from .sat import Clause, formula_energy, formula_satisfied

class BipolarHopfield:
    """Asynchronous single-neuron energy descent for clause penalties + biases."""
    def __init__(self, n_neurons: int, clauses: list[Clause] | None = None,
                 biases=None, max_sweeps: int = 200, seed: int = 1):
        if n_neurons < 1:
            raise ValueError("n_neurons must be positive.")
        self.n = int(n_neurons)
        self.clauses = list(clauses or [])
        self.biases = np.zeros(self.n, dtype=float) if biases is None else np.asarray(biases, dtype=float)
        if self.biases.shape != (self.n,):
            raise ValueError("biases must have shape (n_neurons,).")
        if any(max(i for i, _ in c.literals) >= self.n for c in self.clauses):
            raise ValueError("Clause references a neuron outside the network.")
        self.max_sweeps = int(max_sweeps)
        self.rng = np.random.default_rng(seed)

    def energy(self, state):
        state = np.asarray(state, dtype=np.int8)
        if state.shape != (self.n,) or not np.all(np.isin(state, [-1, 1])):
            raise ValueError("state must be a bipolar vector of length n_neurons.")
        # E_bias = -b^T s; clause penalties are nonnegative.
        return float(-np.dot(self.biases, state) + formula_energy(state, self.clauses))

    def run(self, initial_state=None):
        state = (self.rng.choice([-1, 1], size=self.n).astype(np.int8)
                 if initial_state is None else np.asarray(initial_state, dtype=np.int8).copy())
        if state.shape != (self.n,) or not np.all(np.isin(state, [-1, 1])):
            raise ValueError("initial_state must be bipolar and match n_neurons.")
        history = [self.energy(state)]
        for _ in range(self.max_sweeps):
            changed = False
            for i in self.rng.permutation(self.n):
                candidate = state.copy()
                candidate[i] *= -1
                e_new = self.energy(candidate)
                if e_new < history[-1] - 1e-12:
                    state = candidate
                    history.append(e_new)
                    changed = True
            if not changed:
                break
        return {
            "state": state,
            "energy_history": np.asarray(history, dtype=float),
            "terminal_energy": float(history[-1]),
            "satisfied": formula_satisfied(state, self.clauses),
        }
