from __future__ import annotations
import numpy as np
from sklearn.metrics import f1_score
from .fuzzy import interval_type2_gaussian, interval_score
from .afsa import ArtificialFishSwarm
from .hopfield import BipolarHopfield
from .sat import Clause

class IT2HNNBinaryClassifier:
    """Binary class-prototype IT2 classifier with AFSA spread tuning and HNN output.

    This is a transparent reference model, not the complete manuscript neuron
    construction. For each class/feature, a Gaussian IT2 membership interval
    is calculated around the training-class mean. Feature memberships are
    averaged to obtain class support. A two-neuron HNN selects exactly one class
    using a pair of Boolean clauses for the one-hot constraint.
    """
    def __init__(self, afsa_options=None, hnn_max_sweeps=200, seed=1):
        self.afsa_options = afsa_options or {}
        self.hnn_max_sweeps = hnn_max_sweeps
        self.seed = seed

    def _fit_prototypes(self, X, y):
        self.means_ = np.vstack([X[y == c].mean(axis=0) for c in (0, 1)])
        self.stds_ = np.vstack([X[y == c].std(axis=0, ddof=0) for c in (0, 1)])
        global_std = np.maximum(X.std(axis=0, ddof=0).to_numpy(), 1e-3)
        self.stds_ = np.where(self.stds_ < 1e-3, global_std[None, :], self.stds_)
        self.feature_names_ = list(X.columns)

    def _scores(self, X, lower_mult, upper_mult, upper_weight=0.5):
        arr = np.asarray(X, dtype=float)
        result = np.zeros((len(arr), 2), dtype=float)
        for c in (0, 1):
            lo, hi = interval_type2_gaussian(
                arr, self.means_[c], self.stds_[c] * lower_mult,
                self.stds_[c] * upper_mult)
            result[:, c] = interval_score(lo, hi, upper_weight).mean(axis=1)
        return result

    def _decode_hnn(self, class_scores, sample_seed):
        # y0 OR y1 and not(y0 AND y1), represented as two clauses.
        clauses = [
            Clause(((0, True), (1, True)), weight=2.0),
            Clause(((0, False), (1, False)), weight=2.0),
        ]
        preds = []
        for row_idx, scores in enumerate(class_scores):
            # E_bias = -b*s; bias is proportional to class support.
            biases = np.asarray(scores, dtype=float)
            net = BipolarHopfield(2, clauses=clauses, biases=biases,
                                  max_sweeps=self.hnn_max_sweeps,
                                  seed=sample_seed + row_idx)
            out = net.run()
            # Bipolar +1 denotes selected class; exactly one should be +1.
            active = np.flatnonzero(out["state"] == 1)
            if len(active) != 1:
                # Deterministic safe fallback if the local search ends at an
                # invalid one-hot state; record this behaviour in metrics.
                active = [int(np.argmax(scores))]
            preds.append(int(active[0]))
        return np.asarray(preds, dtype=int)

    def fit(self, X, y, X_valid=None, y_valid=None):
        y = np.asarray(y, dtype=int)
        if set(np.unique(y)) - {0, 1}:
            raise ValueError("Labels must be encoded as 0 and 1.")
        self._fit_prototypes(X, y)
        if X_valid is None or y_valid is None:
            # No validation set supplied: use neutral spread defaults.
            self.best_parameters_ = np.array([0.8, 1.2])
            self.afsa_result_ = None
            return self

        y_valid = np.asarray(y_valid, dtype=int)
        def objective(params):
            lower_mult, upper_mult = params
            if lower_mult <= 0 or upper_mult <= lower_mult:
                return -1.0
            scores = self._scores(X_valid, lower_mult, upper_mult)
            pred = self._decode_hnn(scores, self.seed)
            return float(f1_score(y_valid, pred, zero_division=0))

        opts = dict(population_size=50, max_iterations=500, visual=1.0,
                    step=0.1, crowding_factor=0.618, try_number=5,
                    visual_decay=0.7, step_decay=0.7, elite_count=2,
                    tolerance=1e-6)
        opts.update(self.afsa_options)
        # Bounds preserve sigma_upper > sigma_lower by using lower in [0.3,1.0]
        # and upper multiplier in [1.05,2.0]; the objective rejects invalid pairs.
        afsa = ArtificialFishSwarm([(0.3, 1.0), (1.05, 2.0)], seed=self.seed, **opts)
        self.afsa_result_ = afsa.optimize(objective)
        self.best_parameters_ = self.afsa_result_["x"]
        return self

    def predict_scores(self, X):
        if not hasattr(self, "best_parameters_"):
            raise RuntimeError("Call fit before prediction.")
        return self._scores(X, *self.best_parameters_)

    def predict_proba(self, X):
        scores = self.predict_scores(X)
        # Stable softmax for a probability-like ranking score.
        shifted = scores - scores.max(axis=1, keepdims=True)
        exp = np.exp(shifted)
        return exp / exp.sum(axis=1, keepdims=True)

    def predict(self, X):
        scores = self.predict_scores(X)
        return self._decode_hnn(scores, self.seed)
