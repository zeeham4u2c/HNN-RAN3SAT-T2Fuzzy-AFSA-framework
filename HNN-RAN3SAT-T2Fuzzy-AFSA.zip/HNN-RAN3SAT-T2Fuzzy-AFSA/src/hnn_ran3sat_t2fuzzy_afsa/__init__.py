"""HNN-RAN3SAT-T2Fuzzy-AFSA reference implementation."""
__version__ = "0.1.0"
