from __future__ import annotations
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import MinMaxScaler
from sklearn.pipeline import Pipeline

def make_preprocessor():
    """Fit only on training data; median imputation then scaling to [-1, 1]."""
    return Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", MinMaxScaler(feature_range=(-1, 1), clip=True)),
    ])

def prepare_xy(frame: pd.DataFrame, target: str):
    if target not in frame.columns:
        raise KeyError(f"Target column {target!r} not found.")
    y = frame[target]
    X = frame.drop(columns=[target]).select_dtypes(include=[np.number]).copy()
    if X.empty:
        raise ValueError("No numeric predictor columns were found.")
    if y.isna().any():
        raise ValueError("Target contains missing values; resolve them explicitly.")
    labels = sorted(pd.unique(y))
    if len(labels) != 2:
        raise ValueError(f"This prototype expects exactly two target classes; found {len(labels)}.")
    mapping = {labels[0]: 0, labels[1]: 1}
    return X, y.map(mapping).astype(int), mapping

def optional_smote(X, y, seed=1, max_ratio=3.0):
    """Apply SMOTE to training data only, and only if it does not exceed ratio."""
    from collections import Counter
    counts = Counter(y)
    minority = min(counts.values())
    majority = max(counts.values())
    if minority == 0 or majority / minority <= max_ratio:
        return X, y
    try:
        from imblearn.over_sampling import SMOTE
    except ImportError as exc:
        raise RuntimeError("Install imbalanced-learn to use SMOTE.") from exc
    # SMOTE's default k_neighbors requires enough minority observations.
    k = min(5, minority - 1)
    if k < 1:
        return X, y
    return SMOTE(random_state=seed, k_neighbors=k).fit_resample(X, y)
