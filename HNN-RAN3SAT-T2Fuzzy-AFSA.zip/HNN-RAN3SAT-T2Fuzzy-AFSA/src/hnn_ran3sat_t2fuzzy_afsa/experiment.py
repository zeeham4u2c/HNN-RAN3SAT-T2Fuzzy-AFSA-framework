from __future__ import annotations
import argparse, json
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from .preprocessing import prepare_xy, make_preprocessor
from .classifier import IT2HNNBinaryClassifier
from .metrics import evaluate_binary, roc_table

def run_experiment(csv_path, target, output_dir, seed=1, test_size=0.2,
                   validation_size=0.2, afsa_iterations=500, population_size=50):
    frame = pd.read_csv(csv_path)
    X, y, label_mapping = prepare_xy(frame, target)
    X_train_full, X_test, y_train_full, y_test = train_test_split(
        X, y, test_size=test_size, random_state=seed, stratify=y)
    X_train, X_valid, y_train, y_valid = train_test_split(
        X_train_full, y_train_full, test_size=validation_size,
        random_state=seed + 1000, stratify=y_train_full)

    prep = make_preprocessor()
    X_train_p = pd.DataFrame(prep.fit_transform(X_train), columns=X.columns, index=X_train.index)
    X_valid_p = pd.DataFrame(prep.transform(X_valid), columns=X.columns, index=X_valid.index)
    X_train_full_p = pd.DataFrame(prep.transform(X_train_full), columns=X.columns, index=X_train_full.index)
    X_test_p = pd.DataFrame(prep.transform(X_test), columns=X.columns, index=X_test.index)

    model = IT2HNNBinaryClassifier(
        afsa_options={"max_iterations": afsa_iterations, "population_size": population_size},
        seed=seed)
    model.fit(X_train_p, y_train, X_valid_p, y_valid)
    pred = model.predict(X_test_p)
    prob = model.predict_proba(X_test_p)[:, 1]

    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    metrics = evaluate_binary(y_test, pred, prob)
    metrics.update({
        "seed": int(seed),
        "label_mapping": {str(k): int(v) for k, v in label_mapping.items()},
        "selected_numeric_features": list(X.columns),
        "afsa_best_parameters": model.best_parameters_.tolist(),
        "afsa_best_validation_f1": None if model.afsa_result_ is None else float(model.afsa_result_["score"]),
        "afsa_iterations": int(afsa_iterations),
        "afsa_population_size": int(population_size),
        "implementation_scope": "reference prototype; not a reproduction of manuscript-reported results",
    })
    (output / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    pd.DataFrame({"y_true": y_test.to_numpy(), "y_pred": pred, "score_class_1": prob},
                 index=y_test.index).to_csv(output / "predictions.csv", index_label="row_index")
    roc = roc_table(y_test, prob)
    pd.DataFrame(roc).to_csv(output / "roc_curve.csv", index=False)
    # Record exact split row indices and feature list for auditability.
    (output / "split_indices.json").write_text(json.dumps({
        "train": X_train_full.index.tolist(), "validation": X_valid.index.tolist(),
        "test": X_test.index.tolist(), "features": list(X.columns)
    }, indent=2), encoding="utf-8")
    return metrics

def main():
    parser = argparse.ArgumentParser(description="Run HNN-RAN3SAT-T2Fuzzy-AFSA reference experiment.")
    parser.add_argument("--csv", required=True)
    parser.add_argument("--target", required=True)
    parser.add_argument("--output", default="results/run_01")
    parser.add_argument("--seed", type=int, default=1)
    parser.add_argument("--test-size", type=float, default=0.2)
    parser.add_argument("--validation-size", type=float, default=0.2)
    parser.add_argument("--afsa-iterations", type=int, default=500)
    parser.add_argument("--population-size", type=int, default=50)
    args = parser.parse_args()
    result = run_experiment(args.csv, args.target, args.output, args.seed,
                            args.test_size, args.validation_size,
                            args.afsa_iterations, args.population_size)
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
