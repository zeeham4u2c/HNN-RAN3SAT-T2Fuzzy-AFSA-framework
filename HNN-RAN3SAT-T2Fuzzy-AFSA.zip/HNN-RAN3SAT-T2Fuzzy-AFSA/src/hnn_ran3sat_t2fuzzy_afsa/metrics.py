from __future__ import annotations
import numpy as np
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                             f1_score, roc_auc_score, matthews_corrcoef,
                             confusion_matrix, roc_curve, brier_score_loss)

def evaluate_binary(y_true, y_pred, y_score):
    y_true = np.asarray(y_true, dtype=int)
    y_pred = np.asarray(y_pred, dtype=int)
    y_score = np.asarray(y_score, dtype=float)
    result = {
        "n_test": int(len(y_true)),
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "precision": float(precision_score(y_true, y_pred, zero_division=0)),
        "recall": float(recall_score(y_true, y_pred, zero_division=0)),
        "f1": float(f1_score(y_true, y_pred, zero_division=0)),
        "mcc": float(matthews_corrcoef(y_true, y_pred)),
        "confusion_matrix_labels_0_1": confusion_matrix(y_true, y_pred, labels=[0, 1]).tolist(),
        "brier_score": float(brier_score_loss(y_true, y_score)),
    }
    result["roc_auc"] = float(roc_auc_score(y_true, y_score)) if len(np.unique(y_true)) == 2 else None
    return result

def roc_table(y_true, y_score):
    fpr, tpr, thresholds = roc_curve(y_true, y_score)
    return {"fpr": fpr, "tpr": tpr, "threshold": thresholds}
