from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable, Sequence
import numpy as np

@dataclass(frozen=True)
class Clause:
    """A clause is a tuple of (zero-based variable index, positive_literal)."""
    literals: tuple[tuple[int, bool], ...]
    weight: float = 1.0

    def __post_init__(self):
        if not 1 <= len(self.literals) <= 3:
            raise ValueError("Clause size must be between one and three.")
        if self.weight <= 0:
            raise ValueError("Clause weight must be positive.")
        indices = [i for i, _ in self.literals]
        if len(indices) != len(set(indices)):
            raise ValueError("A clause cannot repeat a variable.")

def literal_values(state: np.ndarray, clause: Clause) -> np.ndarray:
    return np.asarray([state[i] if positive else -state[i]
                       for i, positive in clause.literals], dtype=float)

def clause_penalty(state: np.ndarray, clause: Clause) -> float:
    vals = literal_values(state, clause)
    return float(clause.weight * np.prod((1.0 - vals) / 2.0))

def formula_energy(state: np.ndarray, clauses: Sequence[Clause]) -> float:
    return float(sum(clause_penalty(state, c) for c in clauses))

def is_satisfied(state: np.ndarray, clause: Clause) -> bool:
    return bool(np.any(literal_values(state, clause) > 0))

def formula_satisfied(state: np.ndarray, clauses: Sequence[Clause]) -> bool:
    return all(is_satisfied(state, c) for c in clauses)

def random_3sat(n_variables: int, n_clauses: int, seed: int = 1,
                clause_to_variable_ratio: float | None = None) -> list[Clause]:
    """Generate random 3-literal clauses. Supply n_clauses or a ratio."""
    if n_variables < 3:
        raise ValueError("At least three variables are required.")
    if clause_to_variable_ratio is not None:
        n_clauses = int(round(clause_to_variable_ratio * n_variables))
    if n_clauses < 1:
        raise ValueError("At least one clause is required.")
    rng = np.random.default_rng(seed)
    result = []
    for _ in range(n_clauses):
        vars_ = rng.choice(n_variables, size=3, replace=False)
        signs = rng.choice([False, True], size=3)
        result.append(Clause(tuple((int(v), bool(s)) for v, s in zip(vars_, signs))))
    return result

def encode_and_tseitin(inputs: Sequence[int], output: int) -> list[Clause]:
    """Encode z <-> AND(inputs) as 3-CNF clauses using an auxiliary chain.

    `inputs` and `output` are positive integer variable IDs (1-based).
    The returned clauses are 1-, 2-, or 3-literal tuples of signed DIMACS ints.
    For k>2, fresh variables are allocated above the largest supplied ID.
    """
    if len(inputs) < 1:
        raise ValueError("AND requires at least one input.")
    if output in inputs:
        raise ValueError("Output variable must be distinct from inputs.")
    next_var = max([output, *inputs]) + 1
    clauses: list[tuple[int, ...]] = []
    if len(inputs) == 1:
        a = inputs[0]
        clauses.extend([(-output, a), (output, -a)])
        return clauses
    current = inputs[0]
    for idx, nxt in enumerate(inputs[1:]):
        final = idx == len(inputs) - 2
        z = output if final else next_var
        if not final:
            next_var += 1
        # z <-> (current AND nxt)
        clauses.extend([(-z, current), (-z, nxt), (z, -current, -nxt)])
        current = z
    return clauses

def dimacs_clause_to_clause(lits: Iterable[int], weight: float = 1.0) -> Clause:
    """Convert signed DIMACS literals to internal zero-based Clause."""
    pairs = []
    for lit in lits:
        if lit == 0:
            raise ValueError("DIMACS literal zero is a terminator, not a literal.")
        pairs.append((abs(int(lit)) - 1, int(lit) > 0))
    return Clause(tuple(pairs), weight)
